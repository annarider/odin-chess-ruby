# frozen_string_literal: true

require_relative '../../lib/chess'

# Tests for Castling class
