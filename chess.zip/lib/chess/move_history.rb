# frozen_string_literal: true

require 'digest/md5'

module Chess
  class MoveHistory
    attr_accessor :move_history, :past_positions

    def initialize(move_history = [], past_positions = [])
      @move_history = move_history
      @past_positions = past_positions
    end

    def add_move(move)
      @move_history << move
      add_to_position(move.fen)
    end

    # for 50 move rule
    def count_moves
      move_history.count
    end

    def threefold_repetition?
      return true if count_duplicate_positions.values.any? { |count| count >= 3 }

      false
    end

    # hash position for threefold repetition rule,
    # which omits move clocks from consideration
    def add_to_position(fen_string)
      position = fen_position(fen_string)
      @past_positions << hash_position(position) if position
    end

    def has_moved?(starting_position)
      move_history.any? { |move| move.from_position == starting_position }
    end

    private

    # hash isn't strictly necessary as the FEN string is sufficient
    def hash_position(partial_fen_string)
      Digest::MD5.hexdigest(partial_fen_string.to_s)
    end

    def count_duplicate_positions
      return nil if past_positions.nil?

      count = Hash.new(0)
      past_positions.each { |position| count[position] += 1 }
      count
    end

    def fen_position(fen_string)
      FromFEN.to_piece_placement(fen_string)
    end
  end
end
